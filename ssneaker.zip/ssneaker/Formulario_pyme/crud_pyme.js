function formulario(){
    Response.redirect("../Formulario_pyme/FormularioUsuario.html");
}