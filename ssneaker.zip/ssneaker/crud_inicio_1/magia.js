/*View 1*/
function ocultar1(){
    document.getElementById('noticia1').style.display = 'none';
}
function mostrar1(){
    document.getElementById('noticia1').style.display = 'block';
}
/*View 2*/
function ocultar2(){
    document.getElementById('noticia2').style.display = 'none';
}
function mostrar2(){
    document.getElementById('noticia2').style.display = 'block';
}
/*View 3*/
function ocultar3(){
    document.getElementById('noticia3').style.display = 'none';
}
function mostrar3(){
    document.getElementById('noticia3').style.display = 'block';
}
/*View 4*/
function ocultar4(){
    document.getElementById('noticia4').style.display = 'none';
}
function mostrar4(){
    document.getElementById('noticia4').style.display = 'block';
}
/*View 5*/
function ocultar5(){
    document.getElementById('noticia5').style.display = 'none';
}
function mostrar5(){
    document.getElementById('noticia5').style.display = 'block';
}