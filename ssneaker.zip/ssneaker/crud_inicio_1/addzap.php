<?php
 $conexion=mysqli_connect("localhost","root","","bdssneaker");
 session_start();
  if($_SESSION['id_rol']!=2){
    header("location:../crud_inicio_1/admin.php");
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ssneaker</title>
    <link rel="stylesheet" href="css/addzap.css">
    <link rel="stylesheet" href="css/pyme.css">
</head>
<body>
    <?php
        $ses = $_SESSION['correo'];;
        $consulta = "SELECT * FROM usuario where correo = '".$ses."'";
        $resultado = mysqli_query($conexion, $consulta);   
        while($mostrar=mysqli_fetch_array($resultado)){
        ?>    
  
    <div class="contenedor_bienvenidad">
          <div class="contenedor_foto">
          <img src="img/logo.png" alt="" srcset="">
          </div>
          <h4>Bienvenid@<p><?php echo $mostrar ['nombre_pyme']?></p></h4>
          <hr>
        <nav>
            <div class="contenedor_navegacion">
            <a class="btn btn-outline-secondary" href="pyme.php">📰Inicio</a>
                <a class="btn btn-outline-secondary" href="../crud_pyme_listado/listado.php">Perfil🔒</a>
                <a class="btn btn-outline-secondary" href="../crud_pyme_listado/listado_zapatila.php">Zapatillas Publicadas📈</a>
                <a class="btn btn-outline-secondary" href="../crud_inicio_1/addzap.php">subir Zapatilla🎰</a>
                <a class="btn btn-outline-secondary" href="../crud_cerrarsesion/cerrarsesion.php">Cerrar Session🔓</a>
            
            </div>
        </nav>
</div>
        <?php } ?>
<!--Esto es el contenido central de la pagina-->
    <main>
        <div class="instrucciones">
            <h2>Hola, estoy aqui para ayudarte</h2>
            <p>Recuerda que debes adjuntar 6 fotos para comprobar que son zapatillas reales,
                el orden correspondiente es: Lado derecho, lado izquierdo, de frente, por atras, por arriba y por abajo.
            </p>
        </div>
        <div class="main">
            <form class="formulario" action="https://formsubmit.co/Ssneaker@outlook.com" enctype="multipart/form-data" method="POST">
                <div class="baul_titulo">
                    <div class="baul_h2">
                        <h2>Agregar tu zapatilla es facilisimo</h2>
                    </div>
                    <div class="baul_p">
                        <p>¡Danos la informacion y nosotros lo haremos por ti!</p>
                    </div>
                </div>
                <div class="baul_name_country">
                    <input class="name" type="text" placeholder="Nombre de la zapatilla" name="Nombre_de_la_zapatilla" required>
                    <input class="EstadoZapato" type="text" placeholder="Estado de la zapatilla" name="Estado_de_la_zapatilla" required>
                </div>
                <div class="baul_name_country">
                    <input class="name" type="text" placeholder="Precio" name="Precio" required>
                    <input class="name" type="name" placeholder="Nombre Pyme" name="Nombre_Pyme" required>
                </div>
                <div class="describir">
                    <input class="describirIn" type="text" placeholder="describir zapatilla" name="describir_zapatilla" required>
                </div>
                <div class="baul_foto_telefono">
                    <input class="telefono" type="name" placeholder="+56 9 3001 2000"name="Telefono" required>
                    <input class="img" type="file" name="Derecha" accept="image/png, image/jpeg" required>
                </div>
                <div class="baul_foto_telefono">
                    <input class="img" type="file" name="Izquierda" accept="image/png, image/jpeg" required>
                </div>
                <div class="baul_foto_telefono">
                    <input class="img" type="file" name="Por_debajo" accept="image/png, image/jpeg" required>
                </div>
                <div class="baul_foto_telefono">
                    <input class="img" type="file" name="Por_arriba" accept="image/png, image/jpeg" required>
                </div>
                <div class="baul_foto_telefono">
                    <input class="img" type="file" name="Por_delante" accept="image/png, image/jpeg" required>
                </div>
                <div class="baul_foto_telefono">
                    <input class="img" type="file" name="Por_atras" accept="image/png, image/jpeg" required>
                </div>
                <div class="baul_pass">
                    <input class="direccion" type="name" placeholder="Forma de contacto" name="Forma de contacto" required>
                    <input class="url" type="url" placeholder="URL" name="URL" required>
                </div>
                <div class="aviso_formulario">
                    <p class="p2">Le recomendamos, que una vez enviado el formulario lo revisaremos, cuando la zapatilla sea aprobada sera registrada
                                    eso significa que ya saldra en el buscador del usuario y ademas en su perfil como pyme =), 
                                    intente que las fotos requeridas sean las solicitadas.
                                    ¡Exito!
                    </p>
                </div>
                <div class="baul_register">
                    <input class="register" type="submit" value="Enviar Zapatilla">
                </div>
            </form>
        </div>
        <div class="instrucciones">
            <h2>Hola, estoy aqui para ayudarte</h2>
            <p>Entre mejor sea la calidad de la foto, más rapido podremos verificarla, si necesita comunicarse con nostoros,
                recuerde que existe una pestaña para ello, si tiene alguna duda sobre la politica por favor baje y lea en "politicas"<div class=""></div>
            </p>
        </div>
    </main>
    <footer>
        <div class="empresa">
            <h5>Empresa</h5>
            <li> Contactanos </li>
            <li> Nosotros </li>
        </div>
            <div class="caja_redesSociales">
                <i class="fab fa-facebook-f"></i>
                <i class="fab fa-twitter"></i>
                <i class="fa-brands fa-instagram"></i>
            </div>
            <hr>
            <div class="copyright" align="center">
<div class="contenedorcopy">
<script>
    document.write('&copy;' );
    document.write(' 2022 - ');
    document.write(new Date().getFullYear());
    document.write(' ssneaker.cl - All Rights Reserved.');
    document.write('<br/>Last Updated : ');
    document.write(document.lastModified);
  </script>
</div>

    </div>


</footer>
    <script src="https://kit.fontawesome.com/d7f2da5aa7.js" crossorigin="anonymous"></script>
</body>
</html>